/* eslint-disable */
import * as Router from 'expo-router';

export * from 'expo-router';

declare module 'expo-router' {
  export namespace ExpoRouter {
    export interface __routes<T extends string = string> extends Record<string, unknown> {
      StaticRoutes: `/` | `/(tabs)` | `/(tabs)/` | `/(user)` | `/(user)/Dashboard` | `/(user)/PostComplaint` | `/(user)/Profile` | `/(user)/SOS` | `/(user)/ScratchCard` | `/(user)/TrafficViolation` | `/(user)/ViewComplaints` | `/(user)/ViewViolations` | `/Dashboard` | `/Header` | `/Login` | `/PostComplaint` | `/Profile` | `/Registration` | `/SOS` | `/ScratchCard` | `/TrafficViolation` | `/ViewComplaints` | `/ViewViolations` | `/_sitemap`;
      DynamicRoutes: never;
      DynamicRouteTemplate: never;
    }
  }
}
