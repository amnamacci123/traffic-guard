import React, { useState } from "react";
import {
  StyleSheet,
  TextInput,
  Alert,
  TouchableOpacity,
  View,
} from "react-native";
import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { useRouter } from "expo-router";
import { FontAwesome } from "@expo/vector-icons"; // Importing FontAwesome from Expo icons
import axios from "axios";
import { baseurl } from "./_layout";

const Registration: React.FC = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [mobile, setMobile] = useState("");

  const router = useRouter();

  const handleRegister = async () => {
    if (!name || !email || !password || !mobile) {
      Alert.alert("Please fill all fields");
      return;
    }

    try {
      const response = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "registration",
          username: name,
          email: email,
          password: password,
          mobile: mobile,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      if (response.data.error === 0) {
        // Ensure that the response message is a string
        Alert.alert(
          "Success",
          response.data.message || "Registration successful."
        );
        router.navigate("/Login");
      } else {
        // Handle registration errors
        Alert.alert("Error", response.data.message || "Registration failed.");
      }
    } catch (error) {
      console.error("Error", error);
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    }
  };

  return (
    <ThemedView style={styles.container}>
      <ThemedText type="title" style={styles.titleHead}>
        Join Us
      </ThemedText>
      <ThemedText style={styles.subtitle}>
        Make Your Phone a Partner in Road Safety
      </ThemedText>
      <View style={styles.form}>
        <View style={styles.inputContainer}>
          <FontAwesome
            name="user"
            size={20}
            color="#f4b504"
            style={styles.icon}
          />
          <TextInput
            style={styles.input}
            placeholder="Name"
            value={name}
            onChangeText={setName}
          />
        </View>
        <View style={styles.inputContainer}>
          <FontAwesome
            name="envelope"
            size={20}
            color="#f4b504"
            style={styles.icon}
          />
          <TextInput
            style={styles.input}
            placeholder="Email"
            value={email}
            onChangeText={(text) => setEmail(text.toLowerCase())}
            keyboardType="email-address"
          />
        </View>
        <View style={styles.inputContainer}>
          <FontAwesome
            name="lock"
            size={20}
            color="#f4b504"
            style={styles.icon}
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>
        <View style={styles.inputContainer}>
          <FontAwesome
            name="phone"
            size={20}
            color="#f4b504"
            style={styles.icon}
          />
          <TextInput
            style={styles.input}
            placeholder="Mobile"
            value={mobile}
            onChangeText={setMobile}
            keyboardType="phone-pad"
            maxLength={10}
          />
        </View>
        <TouchableOpacity onPress={handleRegister} style={styles.button}>
          <ThemedText style={styles.buttonText}>REGISTER</ThemedText>
        </TouchableOpacity>
      </View>
    </ThemedView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
    backgroundColor: "#42566f", // Light background for better contrast
  },
  titleHead: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
    color: "#f4b504",
  },
  subtitle: {
    fontSize: 16,
    color: "#ccc",
    marginBottom: 20,
    textAlign: "center",
  },
  form: {
    width: "100%",
    maxWidth: 400,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    backgroundColor: "#fff",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  icon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 16,
  },
  button: {
    backgroundColor: "#f4b504",
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 25,
    alignItems: "center",
    marginTop: 20,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: "bold",
  },
});

export default Registration;
