// Header.tsx
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { StatusBar } from "expo-status-bar";
import React from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";

interface HeaderProps {
  title: string;
}

const Header: React.FC<HeaderProps> = ({ title }) => {
  const router = useRouter();

  function onLogout() {
    router.navigate("/");
  }

  function onHome() {
    router.push("/(user)");
  }

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <View style={styles.homeContainer}>
        <TouchableOpacity onPress={onHome} style={styles.homeButton}>
          <Ionicons name="home" size={24} color="#f4b504" />
          <Text style={styles.title}>{title}</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.logOutContainer}>
        <TouchableOpacity onPress={onLogout} style={styles.logoutButton}>
          <MaterialIcons name="logout" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: "100%",
    height: 100,
    backgroundColor: "#222",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingTop: 20,
    borderBottomWidth: 1,
    borderBottomColor: "#ccc",
  },
  homeContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  homeButton: {
    flexDirection: "row",
    alignItems: "center",
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#f4b504",
    marginLeft: 8,
  },
  logOutContainer: {
    paddingTop: 10,
  },
  logoutButton: {
    backgroundColor: "red",
    padding: 8,
    borderRadius: 20,
  },
});

export default Header;
