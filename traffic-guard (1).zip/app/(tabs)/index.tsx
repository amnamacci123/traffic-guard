import { router } from 'expo-router';
import {  StyleSheet, View,  Text, Image, TouchableOpacity, StatusBar } from 'react-native';

export default function HomeScreen() {

  const gotoLogin = () => {
    router.push("/Login")
   };

  return (
    <View style={styles.container}>
      <StatusBar />
      <Image
        source={require('../../assets/images/traffic.jpg')}
        style={styles.image}
      />
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}  onPress={gotoLogin}>Let's Go </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ffffff',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  buttonContainer: {
    position: 'absolute',
    bottom: 50,
  },
  button: {
    backgroundColor: '#f4b504',
    padding: 10,
    borderRadius: 25,
    width: 130,
    alignItems: 'center',
    marginBottom: 10, 
  },
  buttonText: {
    fontSize: 16,
    fontWeight:"bold"
  },
  linkButton: {
    backgroundColor: 'transparent', 
    borderColor: '#0d8cb9',
    borderWidth: 1,
  },
  linkButtonText: {
    color: '#0d8cb9', 
  },
});
