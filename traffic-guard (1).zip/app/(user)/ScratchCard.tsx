import { useRouter } from 'expo-router';
import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, ImageBackground } from 'react-native';

interface ScratchCardProps {
  reward: string;
  onRedeem: () => void; 
}

const ScratchCard: React.FC<ScratchCardProps> = ({ onRedeem }) => {
  return (
    <TouchableOpacity onPress={onRedeem} style={styles.card}>
      <View style={styles.cover}>
        <Text style={styles.coverText}>Scratch to Reveal</Text>
      </View>
    </TouchableOpacity>
  );
};

const RewardsScreen: React.FC = () => {
  const rewards = ['₹100', '₹200', '₹500', '₹1000', '₹50'];
  const [currentReward, setCurrentReward] = useState<string | null>(null);
  const [scratched, setScratched] = useState(false);

  const getRandomReward = () => {
    const randomIndex = Math.floor(Math.random() * rewards.length);
    setCurrentReward(rewards[randomIndex]);
  };

  useEffect(() => {
    getRandomReward();
    setScratched(false);
  }, []);

  const handleRedeem = () => {
    setScratched(true); 
  };

  const router = useRouter();

  const handleClose = () => {
    setScratched(false); 
    router.push("/(user)")
  };

  return (
    <View style={styles.rewardContainer}>
      {scratched ? (
        <ImageBackground 
          source={require('../../assets/images/reward.gif')} 
          style={styles.background}
          resizeMode="cover"
        >
          <View style={styles.reveal}>
            <View style={styles.revealTextContainer}>
              <Text style={styles.revealText}>Congratulations!</Text>
              <Text style={styles.revealText}>🎉🥳🎊🎁</Text>
              <Text style={styles.revealText}>You Won {currentReward}</Text>
            </View>
            <TouchableOpacity onPress={handleClose} style={styles.closeButton}>
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </ImageBackground>
      ) : (
        <>
          <Text style={styles.rewardTitle}>Redeem Your Rewards</Text>
          <ScratchCard reward={currentReward} onRedeem={handleRedeem} />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    width: '90%',
    height: 150,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 10,
    elevation: 5,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    backgroundColor: 'black',
  },
  background: {
    width: '100%',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cover: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 10,
    backgroundColor: '#222',
  },
  coverText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  reveal: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  revealTextContainer: {
    backgroundColor: '#10058f',
    width: '90%',
    height: 250,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  revealText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    marginVertical: 10,
    textAlign: 'center',
  },
  rewardContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    padding: 20,
  },
  rewardTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  closeButton: {
    marginTop: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: 'grey', // Customize color as needed
    borderRadius: 25,
  },
  closeButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

export default RewardsScreen;
