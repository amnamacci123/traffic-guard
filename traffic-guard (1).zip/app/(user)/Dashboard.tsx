import React, { useEffect, useState } from "react";
import { StyleSheet, View, Text, TouchableOpacity, Alert, ActivityIndicator } from "react-native";
import { FontAwesome, MaterialIcons, MaterialCommunityIcons } from "@expo/vector-icons";
import Header from "../Header";
import SOSButton from "./SOS";
import { useRouter } from "expo-router";
import * as SecureStore from "expo-secure-store";
import { baseurl } from "../_layout";
import axios from "axios";

interface User {
  email: string;
  address: string;
  mobile: string;
  familymobile: string;
  username: string;
}

const Dashboard: React.FC = () => {
  const router = useRouter();
  const [userData, setUserData] = useState<User | null>(null);

  const fetchUser = async () => {
    try {
      const userData = await SecureStore.getItemAsync("user");
      if (userData) {
        const parsedData = JSON.parse(userData);
        const response = await axios.post(
          baseurl,
          new URLSearchParams({
            tag: "getuserdatabymobile",
            mobile: parsedData.mobile,
          }),
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
          }
        );

        if (response.data && response.data.username) {
          setUserData(response.data);
        } else {
          Alert.alert("Error", "User data is not in the expected format.");
        }
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
      Alert.alert("Failed to retrieve user data.");
    }
  };

  useEffect(() => {
    fetchUser(); 

    const intervalId = setInterval(() => {
      fetchUser(); 
    }, 60000); 

    return () => clearInterval(intervalId); 
  }, []);

  const handleTrafficViolation = () => {
    router.navigate("/(user)/TrafficViolation");
  };

  const handlePostComplaint = () => {
    router.navigate('/(user)/PostComplaint');
  };

  const handleScratchCard = () => {
    router.navigate('/(user)/ScratchCard');
  };

  const handleProfile = () => {
    router.navigate("/(user)/Profile");
  };
  const handleViewViolation = () => {
    router.navigate("/(user)/ViewViolations");
  };
  const handleViewComplaints = () => {
    router.navigate("/(user)/ViewComplaints");
  };

  return (
    <View>
      <Header title="Dashboard" />
      {userData ? (
        <>
          <Text style={styles.title}>Welcome {userData.username || "User"}</Text>
        </>
      ) : (
        <ActivityIndicator size="large" color="#f4b504" />
      )}
      <View style={styles.row}>
        <TouchableOpacity style={styles.card} onPress={handleTrafficViolation}>
          <FontAwesome name="exclamation-triangle" size={40} color="#fff" />
          <Text style={styles.cardText}>Post Traffic Violation</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card} onPress={handlePostComplaint}>
          <FontAwesome name="comment" size={40} color="#fff" />
          <Text style={styles.cardText}>Post Your Complaint</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.row}>
        <TouchableOpacity style={styles.card} onPress={handleViewViolation}>
          <FontAwesome name="list-alt" size={40} color="#fff" />
          <Text style={styles.cardText}>View Posted Violation Status</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card} onPress={handleViewComplaints}>
          <FontAwesome name="list-ul" size={40} color="#fff" />
          <Text style={styles.cardText}>View Complaint Status</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.row}>
        <TouchableOpacity style={styles.card} onPress={handleScratchCard}>
          <MaterialCommunityIcons name="gift" size={40} color="#fff" />
          <Text style={styles.cardText}>Rewards</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card} onPress={handleProfile}>
          <MaterialIcons name="account-circle" size={40} color="#fff" />
          <Text style={styles.cardText}>Profile Update</Text>
        </TouchableOpacity>
      </View>

      <SOSButton />
    </View>
  );
};

const styles = StyleSheet.create({
  title: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginVertical: 20,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginBottom: 20,
    marginTop: 20,
    paddingHorizontal: 20,
  },
  card: {
    backgroundColor: "#000",
    padding: 20,
    borderRadius: 15,
    alignItems: "center",
    width: "45%",
  },
  cardText: {
    color: "#f4b504",
    fontSize: 14,
    fontWeight: "bold",
    marginTop: 10,
    textAlign: "center",
  },
});

export default Dashboard;
