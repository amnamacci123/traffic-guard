import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  Alert,
  RefreshControl,
  Modal,
  Image,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import axios from "axios";
import { baseurl } from "../_layout";
import * as SecureStore from "expo-secure-store";
import Header from "../Header";

interface Violation {
  violationid: number;
  type: string;
  image: string;
  description: string;
  datetime: string;
}

const ViewViolations: React.FC = () => {
  const [violations, setViolations] = useState<Violation[]>([]);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [userId, setUserId] = useState<string>("");
  const [modalVisible, setModalVisible] = useState<boolean>(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetchUserId();
  }, []);

  const fetchUserId = async () => {
    try {
      const userData = await SecureStore.getItemAsync("user");
      if (userData) {
        const parsedData = JSON.parse(userData);
        setUserId(parsedData.id);
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
      Alert.alert("Failed to retrieve user data.");
    }
  };

  useEffect(() => {
    if (userId) {
      fetchViolations();
    }
  }, [userId]);

  const fetchViolations = async () => {
    try {
      const response = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "getviolationsdatabyuserid",
          userid: userId,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      if (Array.isArray(response.data)) {
        setViolations(response.data);
      } else {
        Alert.alert("Error", "Data is not in the expected format.");
      }
    } catch (error) {
      console.error("Error fetching violations:", error);
      Alert.alert("Failed to retrieve violations.");
    }
    finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleImagePreview = (imageUrl: string | null) => {
    if (imageUrl) {
      setSelectedImage(imageUrl);
      setModalVisible(true);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      await fetchViolations();
    } catch (error) {
      console.error("Error during refresh:", error);
    } finally {
      setRefreshing(false);
    }
  };

  const renderItem = ({ item }: { item: Violation }) => (
    <View style={styles.itemContainer}>
      <Text style={styles.itemDescription}>ID: {item.violationid}</Text>
      <Text style={styles.itemTitle}>Type: {item.type}</Text>
      <Text style={styles.itemDescription}>
        Description: {item.description}
      </Text>
      <Text style={styles.itemDate}>Date: {item.datetime}</Text>
      {item.image && (
        <TouchableOpacity onPress={() => handleImagePreview(item.image)}>
          <Text style={styles.imageLink}>View Image</Text>
        </TouchableOpacity>
      )}
    </View>
  );
  

  return (
    <View style={styles.wrapper}>
      <Header title="View Complaints" />
        <Text style={styles.header}>Your Reported Violations</Text>
        {loading ? (
          <ActivityIndicator size="large" color="#f4b504" />
        ) : violations.length > 0 ? (
          <FlatList
            data={violations}
            renderItem={renderItem}
            keyExtractor={(item) => item.violationid.toString()}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
            }
            contentContainerStyle={{ paddingBottom: 20 }}
          />
        ) : (
          <Text style={styles.noComplaintsText}>No Complaints Found</Text>
        )}
 

        {/* Image Modal */}
        <Modal
          visible={modalVisible}
          transparent={true}
          animationType="fade"
          onRequestClose={() => setModalVisible(false)}
        >
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              {selectedImage && (
                <Image
                  source={{ uri: selectedImage }}
                  style={styles.complaintImage}
                />
              )}
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    flex: 1,
    backgroundColor: "#f9f9f9",
  },
  scrollContainer: {
    paddingBottom: 20,
  },
  noComplaintsText: {
    fontSize: 18,
    fontWeight: "600",
    textAlign: "center",
    marginTop: 20,
    color: "#888",
  },
  header: {
    fontSize: 22,
    fontWeight: "bold",
    textAlign: "center",
    marginVertical: 20,
    color: "#333",
  },
  itemContainer: {
    backgroundColor: "#fff",
    padding: 16,
    marginHorizontal: 16,
    marginBottom: 10,
    borderRadius: 10,
    elevation: 3,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#444",
  },
  itemDescription: {
    fontSize: 14,
    color: "#666",
    marginVertical: 4,
  },
  imageLink: {
    color: "#1e90ff",
    marginTop: 10,
    fontWeight: "500",
    textDecorationLine: "underline",
  },
  itemDate: {
    fontSize: 12,
    color: "#888",
    marginTop: 8,
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.6)",
  },
  modalContent: {
    backgroundColor: "#fff",
    borderRadius: 12,
    padding: 20,
    alignItems: "center",
  },
  closeButton: {
    backgroundColor: "#f4b504",
    paddingVertical: 8,
    paddingHorizontal: 25,
    borderRadius: 6,
    marginTop: 15,
  },
  closeButtonText: {
    color: "#fff",
    fontWeight: "600",
  },
  complaintImage: {
    width: 300,
    height: 300,
    resizeMode: "contain",
    marginBottom: 15,
    borderRadius: 10,
  },
  emptyText: {
    textAlign: "center",
    marginTop: 50,
    fontSize: 18,
    color: "#888",
  },
});

export default ViewViolations;
