import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Linking,
  Image,
  Modal,
  RefreshControl,
} from "react-native";
import axios from "axios";
import Header from "../Header";
import { baseurl } from "../_layout";
import * as SecureStore from "expo-secure-store";

type ComplaintType = {
  id: string;
  description: string;
  image: string;
  latitude: string;
  longitude: string;
  datetime: string;
  response: string;
  status: string;
};

const ViewComplaints: React.FC = () => {
  const [complaints, setComplaints] = useState<ComplaintType[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [userId, setUserId] = useState<string>("");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [modalVisible, setModalVisible] = useState<boolean>(false);

  useEffect(() => {
    fetchUserId();
  }, []);

  useEffect(() => {
    if (userId) {
      fetchComplaints();
    }
  }, [userId]);

  const fetchUserId = async () => {
    try {
      const userData = await SecureStore.getItemAsync("user");
      if (userData) {
        const parsedData = JSON.parse(userData);
        const response = await axios.post(
          baseurl,
          new URLSearchParams({
            tag: "getuserdatabymobile",
            mobile: parsedData.mobile,
          }),
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
          }
        );
        if (response.data) {
          setUserId(response.data.id);
        }
      }
    } catch (error) {
      console.error("Error fetching user ID:", error);
      Alert.alert("Error", "Failed to fetch user ID");
    }
  };

  const fetchComplaints = async () => {
    try {
      const response = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "getcomplaintbyuserid",
          userid: userId,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );

      if (response.data && Array.isArray(response.data)) {
        setComplaints(response.data);
      } else {
        setComplaints([]);
      }
    } catch (error) {
      console.error("Error fetching complaints:", error);
      Alert.alert("Error", "Failed to load complaints");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const openMap = (latitude: any, longitude: any) => {
    const mapLink = `https://www.google.com/maps?q=${latitude},${longitude}`;
    Linking.openURL(mapLink);
  };

  const handleImagePreview = (imageUrl: string) => {
    setSelectedImage(imageUrl);
    setModalVisible(true);
  };

  const renderComplaint = ({ item }: { item: ComplaintType }) => (
    <View style={styles.complaintCard}>
      <Text style={styles.complaintTitle}>Complaint ID: {item.id}</Text>
      <Text style={styles.complaintText}>Complaint: {item.description}</Text>
      <Text style={styles.complaintText}>
        Response: {item.response ? item.response : "Not yet replied"}
      </Text>
      <Text style={styles.complaintText}>
        Location:{" "}
        <Text
          style={{ color: "blue", textDecorationLine: "underline" }}
          onPress={() => openMap(item.latitude, item.longitude)}
        >
          View Map
        </Text>
      </Text>
      <Text
        style={[
          styles.complaintText,
          item.status.toLowerCase() === "completed"
            ? styles.completedStatus
            : styles.pendingStatus,
        ]}
      >
        Status: {item.status}
      </Text>
      <Text style={styles.complaintText}>Posted Date: {item.datetime}</Text>
      {item.image && (
        <TouchableOpacity onPress={() => handleImagePreview(item.image)}>
          <Text style={styles.imageLink}>View Image</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  const onRefresh = () => {
    setRefreshing(true);
    fetchComplaints();
  };

  return (
    <View style={{ flex: 1 }}>
      <Header title="View Complaints" />
      <View style={styles.container}>
        {loading ? (
          <ActivityIndicator size="large" color="#f4b504" />
        ) : complaints.length > 0 ? (
          <FlatList
            data={complaints}
            renderItem={renderComplaint}
            keyExtractor={(item) => item.id.toString()}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
            }
            contentContainerStyle={{ paddingBottom: 20 }}
          />
        ) : (
          <Text style={styles.noComplaintsText}>No Complaints Found</Text>
        )}
      </View>

      <Modal
        visible={modalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            {selectedImage && (
              <Image
                source={{ uri: selectedImage }}
                style={styles.complaintImage}
              />
            )}
            <TouchableOpacity
              style={styles.closeButton}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.closeButtonText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: 20,
  },
  complaintCard: {
    backgroundColor: "#f9f9f9",
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    elevation: 3,
  },
  complaintTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#000",
    marginBottom: 8,
  },
  complaintText: {
    fontSize: 14,
    marginBottom: 5,
  },
  completedStatus: {
    color: "green",
    fontWeight: "bold",
  },
  pendingStatus: {
    color: "red",
    fontWeight: "bold",
  },
  noComplaintsText: {
    fontSize: 18,
    fontWeight: "600",
    textAlign: "center",
    marginTop: 20,
    color: "#888",
  },
  imageLink: {
    color: "#1e90ff",
    marginTop: 10,
    fontWeight: "500",
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.5)",
  },
  modalContent: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 20,
    alignItems: "center",
  },
  complaintImage: {
    width: 300,
    height: 300,
    resizeMode: "contain",
    marginBottom: 15,
  },
  closeButton: {
    backgroundColor: "#f4b504",
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  closeButtonText: {
    color: "#fff",
    fontWeight: "600",
  },
});

export default ViewComplaints;
