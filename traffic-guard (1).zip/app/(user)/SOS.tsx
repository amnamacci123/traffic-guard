import React, { useEffect, useState } from 'react';
import { StyleSheet, TouchableOpacity, View, Alert } from 'react-native';
import { ThemedText } from '@/components/ThemedText';
import { FontAwesome } from '@expo/vector-icons';
import * as Linking from 'expo-linking';
import * as SecureStore from 'expo-secure-store';
import axios from 'axios';
import { baseurl } from '../_layout';

interface User {
  email: string;
  address: string;
  mobile: string;
  familymobile: string;
  username: string;
}

const SOSButton: React.FC = () => {
  const [data, setData] = useState<User | null>(null);

  useEffect(() => {
    fetchUser();
  }, []);

  const fetchUser = async () => {
    try {
      const userData = await SecureStore.getItemAsync('user');
      if (userData) {
        const parsedData = JSON.parse(userData);
        console.log('Parsed user data:', parsedData); // Debugging log
        const response = await axios.post(
          baseurl,
          new URLSearchParams({
            tag: 'getuserdatabymobile',
            mobile: parsedData.mobile,
          }),
          {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded',
            },
          }
        );

        if (response.data) {
          console.log('Fetched user data from API:', response.data); // Debugging log
          setData(response.data);
        } else {
          Alert.alert('Error', 'User data is not in the expected format.');
        }
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
      Alert.alert('Failed to retrieve user data.');
    }
  };

  const handleSOSPress = () => {
    Alert.alert('Emergency Services', 'Choose an emergency service to call:', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Call Police', onPress: handlePoliceAlert },
      { text: 'More Options', onPress: handleMoreOptionsAlert }, // Opens another alert
    ]);
  };
  
  const handleMoreOptionsAlert = () => {
    Alert.alert('More Options', 'Choose another option:', [
      { text: 'Call Family', onPress: handleFamilyAlert },
      { text: 'Call Ambulance', onPress: handleAmbulanceAlert },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };
  
  const handlePoliceAlert = () => {
    const policeNumber = '100';
    Linking.openURL(`tel:${policeNumber}`);
  };

  const handleAmbulanceAlert = () => {
    const ambulanceNumber = '102';
    Linking.openURL(`tel:${ambulanceNumber}`);
  };

  const handleFamilyAlert = () => {
    if (data?.familymobile) {
      console.log('Calling family mobile:', data.familymobile); // Debugging log
      Linking.openURL(`tel:${data.familymobile}`);
    } else {
      Alert.alert('Error', 'Family mobile number is not available.');
    }
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.button} onPress={handleSOSPress}>
        <FontAwesome name="exclamation-circle" size={24} color="#000" />
        <ThemedText style={styles.buttonText}>SOS</ThemedText>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    padding: 20,
  },
  button: {
    backgroundColor: '#f44336',
    borderRadius: 60,
    padding: 20,
    width: 100,
    alignItems: 'center',
  },
  buttonText: {
    color: '#000',
    marginTop: 5,
    fontWeight: 'bold',
  },
});

export default SOSButton;
