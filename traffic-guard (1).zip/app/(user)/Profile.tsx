import React, { useState, useEffect } from "react";
import {
  StyleSheet,
  TextInput,
  Alert,
  TouchableOpacity,
  View,
  ActivityIndicator,
} from "react-native";
import { ThemedView } from "@/components/ThemedView";
import { ThemedText } from "@/components/ThemedText";
import { FontAwesome, FontAwesome5 } from "@expo/vector-icons";
import axios from "axios";
import Header from "../Header";
import { baseurl } from "../_layout";
import * as SecureStore from "expo-secure-store";

const Profile: React.FC = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [address, setAddress] = useState("");
  const [mobile, setMobile] = useState("");
  const [familyMobile, setFamilyMobile] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    fetchUser();
  }, []);

  const fetchUser = async () => {
    setLoading(true); 
    try {
      const userData = await SecureStore.getItemAsync("user");
      if (userData) {
        const parsedData = JSON.parse(userData);
        const response = await axios.post(
          baseurl,
          new URLSearchParams({
            tag: "getuserdatabymobile",
            mobile: parsedData.mobile,
          }),
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
          }
        );

        setEmail(response.data.email);
        setName(response.data.username);
        setMobile(response.data.mobile);
        setPassword(response.data.password);
        setFamilyMobile(response.data.familymobile);
        setAddress(response.data.address);
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
      Alert.alert("Failed to retrieve user data.");
    } finally {
      setLoading(false); 
    }
  };

  const handleUpdate = async () => {
    if (!name || !email || !password || !mobile || !familyMobile || !address) {
      Alert.alert("Please fill all fields");
      return;
    }
    try {
      const response = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "updateprofile",
          username: name,
          email: email,
          password: password,
          mobile: mobile,
          familymobile: familyMobile,
          address: address,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );
  
      console.log("Response Data:", response.data); 
  
      if (response.data.error === 0) {
        Alert.alert("Success", response.data.message || "Profile updated successfully");
        fetchUser();
      } else {
        Alert.alert("Error", response.data.message || "An error occurred"); 
      }
    } catch (error) {
      console.error("Error updating profile:", error);
      Alert.alert("Error updating profile, please try again.");
    }
  };
  

  return (
    <View>
      <Header title="Update Profile" />
      <ThemedView style={styles.container}>
        <ThemedText type="title" style={styles.titleHead}>
          Update Profile
        </ThemedText>
        {loading ? (
          <ActivityIndicator size="large" color="#f4b504" />
        ) : (
          <View style={styles.form}>
            <View style={styles.inputContainer}>
              <FontAwesome
                name="user"
                size={20}
                color="#f4b504"
                style={styles.icon}
              />
              <TextInput
                style={styles.input}
                placeholder="Name"
                value={name}
                onChangeText={setName}
              />
            </View>
            <View style={styles.inputContainer}>
              <FontAwesome
                name="envelope"
                size={20}
                color="#f4b504"
                style={styles.icon}
              />
              <TextInput
                style={styles.input}
                placeholder="Email"
                value={email}
                onChangeText={(text) => setEmail(text.toLowerCase())}
                keyboardType="email-address"
              />
            </View>
            <View style={styles.inputContainer}>
              <FontAwesome
                name="lock"
                size={20}
                color="#f4b504"
                style={styles.icon}
              />
              <TextInput
                style={styles.input}
                placeholder="Password"
                value={password}
                onChangeText={setPassword}
                secureTextEntry={!showPassword} 
              />
              <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
                <FontAwesome
                  name={showPassword ? "eye" : "eye-slash"}
                  size={20}
                  color="#f4b504"
                  style={styles.icon}
                />
              </TouchableOpacity>
            </View>
            <View style={styles.inputContainer}>
              <FontAwesome
                name="phone"
                size={20}
                color="#f4b504"
                style={styles.icon}
              />
              <TextInput
                style={styles.input}
                placeholder="Mobile"
                value={mobile}
                onChangeText={setMobile}
                keyboardType="phone-pad"
                readOnly
              />
            </View>
            <View style={styles.inputContainer}>
              <FontAwesome5
                name="user-friends"
                size={20}
                color="#f4b504"
                style={styles.icon}
              />
              <TextInput
                style={styles.input}
                placeholder="Family Mobile Number"
                value={familyMobile}
                onChangeText={setFamilyMobile}
                keyboardType="phone-pad"
                maxLength={10}
              />
            </View>
            <View style={styles.inputContainer}>
              <FontAwesome5
                name="map-marker-alt"
                size={20}
                color="#f4b504"
                style={styles.icon}
              />
              <TextInput
                style={[styles.input, styles.textArea]}
                placeholder="Address"
                value={address}
                onChangeText={setAddress}
                keyboardType="default"
                multiline
                numberOfLines={4}
              />
            </View>

            <TouchableOpacity onPress={handleUpdate} style={styles.button}>
              <ThemedText style={styles.buttonText}>UPDATE</ThemedText>
            </TouchableOpacity>
          </View>
        )}
      </ThemedView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    justifyContent: "center",
    alignItems: "center",
    padding: 16,
  },
  titleHead: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  form: {
    width: "100%",
    maxWidth: 400,
  },
  textArea: {
    height: 100, 
    textAlignVertical: "top", 
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    backgroundColor: "#fff",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  icon: {
    marginRight: 8,
  },
  input: {
    flex: 1,
    fontSize: 16,
  },
  button: {
    backgroundColor: "#f4b504",
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderRadius: 25,
    width: 120,
    alignItems: "center",
    marginTop: 20,
  },
  buttonText: {
    fontSize: 16,
    fontWeight: "bold",
  },
});

export default Profile;
