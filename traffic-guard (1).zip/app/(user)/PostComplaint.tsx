import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  Alert,
  Image,
} from "react-native";
import * as ImagePicker from "expo-image-picker";
import Header from "../Header";
import axios from "axios";
import * as FileSystem from "expo-file-system";
import { baseurl } from "../_layout";
import * as SecureStore from 'expo-secure-store'
import * as Location from "expo-location";


type LocationType = {
  latitude: number;
  longitude: number;
} | null;

const PostComplaint: React.FC = () => {
  const [image, setImage] = useState<string | null>(null);
  const [description, setDescription] = useState<string>("");
  const [statusMessage, setStatusMessage] = useState<string>("");
  const [userId, setUserId] = useState('');
  const [userLocation, setUserLocation] = useState<LocationType>(null);

  useEffect(() => {
    fetchUser();
  }, []);

  const fetchUser = async () => {
    try {
      const userData = await SecureStore.getItemAsync("user");
      if (userData) {
        const parsedData = JSON.parse(userData);
        const response = await axios.post(
          baseurl,
          new URLSearchParams({
            tag: "getuserdatabymobile",
            mobile: parsedData.mobile,
          }),
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
          }
        );

        if (response.data ) {
          setUserId(response.data.id);
        } else {
          Alert.alert("Error", "User data is not in the expected format.");
        }
      }
    } catch (error) {
      console.error("Error fetching user data:", error);
      Alert.alert("Failed to retrieve user data.");
    }
  };


  useEffect(() => {
    getUserLocation();
  }, []);

  const getUserLocation = async () => {
    try {
      let { status } = await Location.requestForegroundPermissionsAsync();

      if (status !== "granted") {
        console.error("Location permission not granted");
        return;
      }

      let location = await Location.getCurrentPositionAsync({});
      setUserLocation({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });
    } catch (error:any) {
      console.error("Error getting user location:", error.message);
    }
  };

  const getCurrentDateTime = () => {
    const now = new Date();
  
    const day: string = String(now.getDate()).padStart(2, '0');
    const month: string = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const year: number = now.getFullYear();
  
    let hours: string = String(now.getHours() % 12 || 12).padStart(2, '0'); // Convert hours directly to string
    const minutes: string = String(now.getMinutes()).padStart(2, '0');
    const ampm: string = now.getHours() >= 12 ? 'PM' : 'AM';
  
    return `${day}-${month}-${year} ${hours}:${minutes} ${ampm}`;
  };
  

  const pickImage = async () => {
    const permissionResult =
      await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (permissionResult.granted === false) {
      Alert.alert("Permission to access camera is required!");
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync();

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const captureImage = async () => {
    const permissionResult = await ImagePicker.requestCameraPermissionsAsync();

    if (permissionResult.granted === false) {
      Alert.alert("Permission to access camera is required!");
      return;
    }

    const result = await ImagePicker.launchCameraAsync();

    if (!result.canceled) {
      setImage(result.assets[0].uri);
    }
  };

  const handleSubmit = async () => {
  
    if (!description) {
      Alert.alert("Please enter a description.");
      return;
    }
  
    if (!image) {
      Alert.alert("Please upload or capture an image.");
      return;
    }
  
    try {
      // Read the image as base64
      const base64 = await FileSystem.readAsStringAsync(image, {
        encoding: FileSystem.EncodingType.Base64,
      });
  
      // Create the Data URL
      const dataUrl = `data:image/jpeg;base64,${base64}`;

      const currentDateTime = getCurrentDateTime();
  
      // Prepare and send the POST request
      const response = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "postcomplaints",
          description :description,
          image: dataUrl,
          userid: userId,
          latitude: String(userLocation?.latitude),
          longitude: String(userLocation?.longitude),
          datetime: currentDateTime,
        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );
  
      // Check the response
      if (response.data.error === 0) {
        Alert.alert("Success", response.data.message || "Complaint reported successfully!");
        setStatusMessage("Complaint reported successfully!");
        setImage(null);
        setDescription("");
      } else {
        Alert.alert("Error", response.data.message || "An error occurred while reporting the complaint.");
      }
    } catch (error) {
      console.error("Error submitting complaint:", error);
      Alert.alert("Failed to report the complaint. Please try again.");
    }
  };
  

  return (
    <View style={styles.container}>
      <Header title="Dashboard" />
      <View style={styles.innerContainer}>
        <Text style={styles.title}>Report Traffic Violation</Text>
        {/* Button Wrapper for Horizontal Layout */}
        <View style={styles.buttonRow}>
          <TouchableOpacity style={styles.imageButton} onPress={pickImage}>
            <Text style={styles.imageButtonText}>
              {image ? "Change Image" : "Upload Image"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.imageButton} onPress={captureImage}>
            <Text style={styles.imageButtonText}>Take a Photo</Text>
          </TouchableOpacity>
        </View>

        {image && <Image source={{ uri: image }} style={styles.imagePreview} />}

        <TextInput
          style={styles.input}
          placeholder="Description"
          value={description}
          onChangeText={setDescription}
          multiline
          numberOfLines={4}
        />

        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitButtonText}>Submit</Text>
        </TouchableOpacity>

        {statusMessage && (
          <Text style={styles.statusMessage}>{statusMessage}</Text>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  innerContainer: {
    padding: 30,
  },
  title: {
    fontSize: 18,
    fontWeight: "700",
    marginBottom: 15,
    textAlign: "center",
    color: "#333",
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  imageButton: {
    backgroundColor: "#f4b504",
    paddingVertical: 10,
    borderRadius: 30,
    alignItems: "center",
    flex: 1,
    marginHorizontal: 5,
    marginVertical: 5,
    elevation: 3,
  },
  imageButtonText: {
    fontSize: 14,
    fontWeight: "500",
  },
  imagePreview: {
    width: "100%",
    height: 200,
    borderRadius: 12,
    marginVertical: 10,
    alignSelf: "center",
    resizeMode: "cover",
    borderColor: "#ccc",
    borderWidth: 1,
  },
  input: {
    height: 100,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
    backgroundColor: "#f9f9f9",
  },
  picker: {
    height: 50,
    width: "100%",
    marginBottom: 15,
    borderColor: "#ccc",
    borderWidth: 1,
    borderRadius: 8,
  },
  submitButton: {
    backgroundColor: "#f4b504",
    paddingVertical: 10,
    borderRadius: 30,
    alignItems: "center",
    elevation: 3,
    width: 150,
    alignSelf: "center",
  },
  submitButtonText: {
    fontSize: 16,
    fontWeight: "600"
  },
  statusMessage: {
    marginTop: 15,
    fontSize: 16,
    fontWeight: "600",
    color: "#28A745",
    textAlign: "center",
  },
});

export default PostComplaint;
