import React, { useState } from 'react';
import { ImageBackground, StyleSheet, TextInput, TouchableOpacity, Text, View, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { ThemedView } from '@/components/ThemedView';
import { ThemedText } from '@/components/ThemedText';
import { StatusBar } from 'expo-status-bar';
import { FontAwesome, MaterialIcons } from '@expo/vector-icons'; // Importing icons
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import { baseurl } from './_layout';

const Login: React.FC = () => {
  const [id, setId] = useState('');
  const [password, setPassword] = useState('');

  const router = useRouter();

  const handleLogin = async () => {
    if (!password || !id) {
      Alert.alert('Please fill all fields');
      return;
    }
    try {
      const response = await axios.post(
        baseurl,
        new URLSearchParams({
          tag: "login",
          mobile: id,
          password: password,

        }),
        {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
        }
      );
      if (response.data.error === 0) {
        await SecureStore.setItemAsync('user', JSON.stringify(response.data));
        Alert.alert("Login successfully");
          router.push('/(user)/Dashboard');
          console.log(response.data);
          
      } else {
        Alert.alert(response.data.message || "Error");
      }
    } catch (error: any) {
      Alert.alert(error.message || "Invalid ID/ Password");
    }
  };

  const handleRegistration = () => {
    router.push('/Registration');
  };

  return (
    <ImageBackground
      source={require('../assets/images/login.png')}
      style={styles.backgroundImage}
      resizeMode="cover"
    >
      <StatusBar />
      <ThemedView style={styles.overlay}>
        <ThemedText type="title" style={styles.titleHead}>Login</ThemedText>

        {/* User ID Input with Icon */}
        <View style={styles.inputContainer}>
          <FontAwesome name="user" size={24} color="black" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Mobile Number"
            value={id}
            onChangeText={setId}
            keyboardType='phone-pad'
            maxLength={10}
          />
        </View>

        {/* Password Input with Icon */}
        <View style={styles.inputContainer}>
          <MaterialIcons name="lock" size={24} color="black" style={styles.icon} />
          <TextInput
            style={styles.input}
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />
        </View>

        <TouchableOpacity onPress={handleLogin} style={styles.button}>
          <Text style={styles.buttonText}>LOG IN</Text>
        </TouchableOpacity>

        <Text style={styles.lineText}>Don't have an account yet?</Text>
        <TouchableOpacity onPress={handleRegistration}>
          <Text style={styles.regText}>Create an account</Text>
        </TouchableOpacity>
      </ThemedView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    height: '100%',
  },
  overlay: {
    width: '80%',
    maxWidth: 400,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    padding: 20,
    borderRadius: 20,
    alignItems: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'black',
    borderRadius: 8,
    padding: 8,
    marginVertical: 10,
    width: '90%',
    backgroundColor: 'white',
  },
  input: {
    flex: 1,
    fontSize: 16,
    marginLeft: 10,
    textAlign: 'center',
  },
  icon: {
    marginRight: 10,
  },
  regText: {
    color: 'green',
    fontSize: 16,
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: 5,
  },
  lineText: {
    textAlign: 'center',
    fontSize: 14,
    marginTop: 50,
  },
  button: {
    backgroundColor: '#f4b504',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 25,
    width: 150,
    alignItems: 'center',
    marginTop: 20,
  },
  buttonText: {
    fontSize: 14,
    fontWeight: 'bold',
  },
  titleHead: {
    fontSize: 22,
    marginVertical: 20,
  },
});

export default Login;
